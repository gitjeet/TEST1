<!DOCTYPE html>
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">

<head>
  <meta charset="UTF-8" />
  <link rel="stylesheet" property="stylesheet" href="https://www.hypergiant.com/wp-content/themes/hypergiant/dist/styles/main-e4c38acbfc.css" type="text/css">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script>document.querySelector('html').classList.remove('no-js');</script>
      <script src="https://www.hypergiant.com/wp-content/themes/hypergiant/dist/scripts/app-a4f4b99abf.bundle.js" defer></script>
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-114400512-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-114400512-1');
  </script>
  <!-- Google Analytics -->
  <script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-114400512-1', 'auto');
    ga('send', 'pageview');
  </script>
  <!-- End Google Analytics -->
  <!-- Hotjar Tracking Code for https://www.hypergiant.com/ -->
  <script>
      (function(h,o,t,j,a,r){
          h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
          h._hjSettings={hjid:1385742,hjsv:6};
          a=o.getElementsByTagName('head')[0];
          r=o.createElement('script');r.async=1;
          r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
          a.appendChild(r);
      })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
  </script>
  <!-- WebSights  -->
  <script>
    (function () {
      var zi = document.createElement('script');
      zi.type = 'text/javascript';
      zi.async = true;
      zi.src = 'https://ws.zoominfo.com/pixel/nQcfH91HWgNSoKMrCHsq';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(zi, s);
    })();
  </script>
  <noscript><img src="https://ws.zoominfo.com/pixel/nQcfH91HWgNSoKMrCHsq" width="1" height="1" style="display: none;" /></noscript>
  <link rel="pingback" href="https://www.hypergiant.com/xmlrpc.php" />
  <title>Page not found - Hypergiant</title>

<!-- This site is optimized with the Yoast SEO plugin v13.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Hypergiant" />
<meta property="og:site_name" content="Hypergiant" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Hypergiant" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.hypergiant.com/#website","url":"https://www.hypergiant.com/","name":"Hypergiant","inLanguage":"en-US","potentialAction":{"@type":"SearchAction","target":"https://www.hypergiant.com/?s={search_term_string}","query-input":"required name=search_term_string"}}]}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//www.hypergiant.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.hypergiant.com\/wp-includes\/js\/wp-emoji-release.min.js"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://www.hypergiant.com/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp1s-frontend-style-css'  href='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/css/wp1s-frontend-style.css?ver=1.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='wp1s-bxslider-style-css'  href='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/css/jquery.bxslider.css?ver=1.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='wp1s-responsive-style-css'  href='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/css/wp1s-responsive.css?ver=1.2.5' type='text/css' media='all' />
<script type='text/javascript' src='https://www.hypergiant.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_posts = {"ajaxurl":"https:\/\/www.hypergiant.com\/wp-admin\/admin-ajax.php","noposts":"No older posts found"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-content/themes/hypergiant/main.js'></script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/js/jquery.fitvids.js?ver=1.2.5'></script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/js/jquery.bxslider.min.js?ver=1.2.5'></script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-content/plugins/wp-1-slider/js/wp1s-frontend-script.js?ver=1.2.5'></script>
<link rel='https://api.w.org/' href='https://www.hypergiant.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.hypergiant.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.hypergiant.com/wp-includes/wlwmanifest.xml" /> 
<link rel="icon" href="https://www.hypergiant.com/wp-content/uploads/2018/05/cropped-rocket-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.hypergiant.com/wp-content/uploads/2018/05/cropped-rocket-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.hypergiant.com/wp-content/uploads/2018/05/cropped-rocket-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.hypergiant.com/wp-content/uploads/2018/05/cropped-rocket-1-270x270.png" />

    </head>

<body class="error404">
      <div class="c-main-nav" data-menu-element>

  <div class="c-main-nav__container">

    <header class="c-main-nav__header">
      <div class="c-main-nav__logo-container">
        <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 177 80">
  <path class="logo-fill"
    d="M66.54 15.153v21.142h-3.226v-6.473h-8.67v6.473h-3.227V15.123h3.227v11.856h8.67V15.153zM96.785 15.123l-6.4 10.48-.967 1.484.06 2.302v6.906h-3.472v-9.209l-1.118-1.817-6.25-10.146h3.563l4.318 6.966 1.178 1.969 1.177-1.939 4.288-6.996zM112.079 28.191h3.974c2.3-.12 4.213-2.304 4.213-5.088 0-2.575-1.733-4.73-3.914-5.029h-4.273v10.117zm3.257 2.814h-3.257v5.208h-3.137V15.26H116.352c3.764.18 6.782 3.622 6.782 7.843 0 3.233-1.733 6.046-4.243 7.243 0 0-1.165.659-3.555.659zM139.037 18.074v8.92h8.187v2.814h-8.187V33.4h9.561v2.813H135.96V15.26h12.64v2.814zM163.6 28.251h3.944c2.33-.15 4.243-2.364 4.243-5.088 0-2.635-1.733-4.79-3.914-5.06H163.6v10.148zm6.783 2.155l4.183 5.807h-4.004l-3.705-5.178H163.6v5.178h-3.137V15.26H167.873v.06c3.764.12 6.783 3.622 6.783 7.843 0 3.233-1.734 5.986-4.273 7.243zM71.657 57.125c0 6.076-4.273 10.925-10.577 10.925-5.947 0-10.787-4.849-10.787-10.925 0-6.017 4.84-10.985 10.787-10.985 4.571 0 7.021 1.915 8.963 3.831l-2.6 2.035c-1.314-1.227-3.286-2.604-6.363-2.604-4.094 0-7.38 3.442-7.38 7.723 0 4.31 3.286 7.782 7.38 7.782 3.227 0 6.035-1.945 6.931-5.208h-5.228v-2.934h8.874v.36zM85.938 67.706h3.257V46.753h-3.257zM114.086 61.6s-.538-1.168-.747-1.707c-.448-1.257-.896-2.274-1.106-2.873-1.015-2.544-1.553-4.25-1.553-4.25s-.657 1.736-1.674 4.25a75.929 75.929 0 01-1.105 2.873 66.439 66.439 0 01-.717 1.707s.419-.06 3.496-.06c3.048 0 3.406.06 3.406.06m1.046 2.723h-9.023c-.718 1.857-1.315 3.353-1.315 3.353h-3.347l9.173-21.432 9.233 21.432h-3.347s-.597-1.496-1.374-3.353M131.179 46.304l11.533 11.404 2.51 2.605-.03-3.203V46.783h3.436v21.192l-12.1-11.733-2.062-2.215.03 2.604v10.955h-3.317zM176.359 46.813v2.993h-6.275v17.87h-3.525v-17.87h-6.096v-2.993zM0 36.798l2.534 41.84.774-.09-.293-10.986c-.114-1.837.904-3.55 2.493-4.139a24.39 24.39 0 013.365-.979c1.442 3.78 3.21 7.003 5.23 9.827 2.022-2.824 3.79-6.048 5.232-9.827 1.14.245 2.265.571 3.365.98 1.589.587 2.607 2.301 2.493 4.138L24.9 78.548l.774.09 2.534-41.84-.774-.082L26.04 53.67c-.105 1.674-1.124 3.102-2.574 3.616-.88.319-1.785.588-2.697.808 1.621-5.738 2.55-12.619 2.55-21.059 0-16.871-3.715-29.27-9.215-36.975-5.5 7.705-9.215 20.104-9.215 36.975 0 8.44.929 15.321 2.55 21.06-.912-.221-1.817-.49-2.697-.809-1.45-.514-2.469-1.942-2.574-3.616L.774 36.716 0 36.798z" />
</svg>
      </div>

      <div class="c-main-nav__close-container">
        <a href="#" class="c-main-nav__close" data-menu-close></a>
      </div>
    </header>

    <div class="c-main-nav__main">
      <h1 class="c-main-nav__title">Index</h1>

      <div class="c-main-nav__main-links">

        <ul class="c-main-nav__list c-main-nav__list--small">
                                    <li class="c-main-nav__list-item">
                                  <a class="c-main-nav__link" href="https://www.hypergiant.com/" title="Home">Home</a>
                                              </li>
                                                                      <li class="c-main-nav__list-item">
                                  <a class="c-main-nav__link link--parent" href="https://www.hypergiant.com/about/" title="Company">Company</a>
                                                    <ul class="c-main-nav__sub-list">
                                        <li class="c-main-nav__sub-list-item">
                      <a href="https://www.hypergiant.com/rd/" class="c-main-nav__link c-main-nav__link--span-brk  menu-item menu-item-type-post_type menu-item-object-page menu-item-5221">R&#038;D</a>
                    </li>
                                        <li class="c-main-nav__sub-list-item">
                      <a href="https://www.hypergiant.com/a-better-world/" class="c-main-nav__link c-main-nav__link--span-brk  menu-item menu-item-type-post_type menu-item-object-page menu-item-5220">A Better World</a>
                    </li>
                                        <li class="c-main-nav__sub-list-item">
                      <a href="https://www.hypergiant.com/ethics/" class="c-main-nav__link c-main-nav__link--span-brk  menu-item menu-item-type-post_type menu-item-object-page menu-item-5219">Ethics</a>
                    </li>
                                        <li class="c-main-nav__sub-list-item">
                      <a href="https://www.hypergiant.com/partners/" class="c-main-nav__link c-main-nav__link--span-brk  menu-item menu-item-type-post_type menu-item-object-page menu-item-5218">Partners</a>
                    </li>
                                        <li class="c-main-nav__sub-list-item">
                      <a href="https://www.hypergiant.com/advisory/" class="c-main-nav__link c-main-nav__link--span-brk  menu-item menu-item-type-post_type menu-item-object-page menu-item-5222">Advisory</a>
                    </li>
                                      </ul>
                              </li>
                                                                      <li class="c-main-nav__list-item">
                                  <a class="c-main-nav__link" href="https://www.hypergiant.com/case-studies-design-thinking-process/" title="Client Solutions">Client Solutions</a>
                                              </li>
                                                                      <li class="c-main-nav__list-item">
                                  <a class="c-main-nav__link" href="https://www.hypergiant.com/press-page/" title="Press">Press</a>
                                              </li>
                                                                      <li class="c-main-nav__list-item">
                                  <a class="c-main-nav__link" href="https://hypergiant.tv" title="Hypergiant.tv">Hypergiant.tv</a>
                                              </li>
                                                    </ul>

        <ul class="c-main-nav__list c-main-nav__list--small">
                                                          <li class="c-main-nav__list-item">
                <a class="c-main-nav__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-35" href="https://www.hypergiant.com/transcripts/" title="Transcripts">Transcripts</a>
              </li>
                                                                      <li class="c-main-nav__list-item">
                <a class="c-main-nav__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-34" href="https://www.hypergiant.com/careers/" title="Careers">Careers</a>
              </li>
                                                                      <li class="c-main-nav__list-item">
                <a class="c-main-nav__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-33" href="https://www.hypergiant.com/contact/" title="Contact">Contact</a>
              </li>
                                                                      <li class="c-main-nav__list-item">
                <a class="c-main-nav__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-6325" href="https://www.hypergiant.com/signup/" title="Newsletters">Newsletters</a>
              </li>
                                                                      <li class="c-main-nav__list-item">
                <a class="c-main-nav__link   menu-item menu-item-type-custom menu-item-object-custom menu-item-7041" href="https://hypergiant.tv" title="Hypergiant.tv">Hypergiant.tv</a>
              </li>
                              </ul>

        <ul class="c-main-nav__list">
          <li class="c-main-nav__list-item c-main-nav__list-item--parent">
            <a class="c-main-nav__link" href="https://www.hypergiant.com/divisions/">Divisions</a>

            <ul class="c-main-nav__sub-list">
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="https://www.hypergiant.com/divisions/space-age-solutions/"><span>Div 00001</span>   <span>Space age solutions</span></a>
                </li>
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="https://www.hypergiant.com/sensory-sciences/"><span>DIV 00002</span><span>Sensory Sciences</span></a>
                </li>
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="https://www.hypergiant.com/divisions/machine-learning-startups/"><span>Div 00003</span>              <span>Hypergiant ventures</span></a>
                </li>
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="https://www.hypergiant.com/galactic/"><span>Div 00004</span> <span>Galactic Systems</span></a>
                </li>
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="#"><span>Div 00005</span> <span>[Redacted division]</span></a>
                </li>
                              <li class="c-main-nav__sub-list-item">
                  <a class="c-main-nav__link c-main-nav__link--span-brk" href="#"><span>Div 00006</span> <span>[Redacted division]</span></a>
                </li>
                          </ul>

          </li>
        </ul>

      </div>

      <div class="c-main-nav__footer">

        <ul class="c-main-nav__line-list">
                      <li class="c-main-nav__line-list-item">
              <a href="http://twitter.com/hypergiant" class="c-social-link c-social-link--twitter"></a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href="http://www.linkedin.com/company/27027701/" class="c-social-link c-social-link--linkedin"></a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href="http://www.instagram.com/hypergiant/" class="c-social-link c-social-link--instagram"></a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href="http://youtube.com/c/HypergiantIndustries" class="c-social-link c-social-link--youtube"></a>
            </li>
                  </ul>

        <ul class="c-main-nav__line-list">
                      <li class="c-main-nav__line-list-item">
              <a href="https://www.hypergiant.com/privacy/"  class="c-main-nav__link c-main-nav__link--small">Privacy</a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href="https://www.hypergiant.com/terms-of-use/"  class="c-main-nav__link c-main-nav__link--small">Terms</a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href="mailto:Legal@hypergiant.com"  target="_blank" class="c-main-nav__link c-main-nav__link--small">Legal</a>
            </li>
                      <li class="c-main-nav__line-list-item">
              <a href=""  class="c-main-nav__link c-main-nav__link--small"></a>
            </li>
                  </ul>

      </div>

    </div>

  </div>

</div>

<header id="header" class="c-header c-header--non-transparent c-header--fixed">

  <div class="c-header__container">
    <div class="c-header__logo-container">
      <a href="/" title="Home page">
        <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 177 80">
  <path class="logo-fill"
    d="M66.54 15.153v21.142h-3.226v-6.473h-8.67v6.473h-3.227V15.123h3.227v11.856h8.67V15.153zM96.785 15.123l-6.4 10.48-.967 1.484.06 2.302v6.906h-3.472v-9.209l-1.118-1.817-6.25-10.146h3.563l4.318 6.966 1.178 1.969 1.177-1.939 4.288-6.996zM112.079 28.191h3.974c2.3-.12 4.213-2.304 4.213-5.088 0-2.575-1.733-4.73-3.914-5.029h-4.273v10.117zm3.257 2.814h-3.257v5.208h-3.137V15.26H116.352c3.764.18 6.782 3.622 6.782 7.843 0 3.233-1.733 6.046-4.243 7.243 0 0-1.165.659-3.555.659zM139.037 18.074v8.92h8.187v2.814h-8.187V33.4h9.561v2.813H135.96V15.26h12.64v2.814zM163.6 28.251h3.944c2.33-.15 4.243-2.364 4.243-5.088 0-2.635-1.733-4.79-3.914-5.06H163.6v10.148zm6.783 2.155l4.183 5.807h-4.004l-3.705-5.178H163.6v5.178h-3.137V15.26H167.873v.06c3.764.12 6.783 3.622 6.783 7.843 0 3.233-1.734 5.986-4.273 7.243zM71.657 57.125c0 6.076-4.273 10.925-10.577 10.925-5.947 0-10.787-4.849-10.787-10.925 0-6.017 4.84-10.985 10.787-10.985 4.571 0 7.021 1.915 8.963 3.831l-2.6 2.035c-1.314-1.227-3.286-2.604-6.363-2.604-4.094 0-7.38 3.442-7.38 7.723 0 4.31 3.286 7.782 7.38 7.782 3.227 0 6.035-1.945 6.931-5.208h-5.228v-2.934h8.874v.36zM85.938 67.706h3.257V46.753h-3.257zM114.086 61.6s-.538-1.168-.747-1.707c-.448-1.257-.896-2.274-1.106-2.873-1.015-2.544-1.553-4.25-1.553-4.25s-.657 1.736-1.674 4.25a75.929 75.929 0 01-1.105 2.873 66.439 66.439 0 01-.717 1.707s.419-.06 3.496-.06c3.048 0 3.406.06 3.406.06m1.046 2.723h-9.023c-.718 1.857-1.315 3.353-1.315 3.353h-3.347l9.173-21.432 9.233 21.432h-3.347s-.597-1.496-1.374-3.353M131.179 46.304l11.533 11.404 2.51 2.605-.03-3.203V46.783h3.436v21.192l-12.1-11.733-2.062-2.215.03 2.604v10.955h-3.317zM176.359 46.813v2.993h-6.275v17.87h-3.525v-17.87h-6.096v-2.993zM0 36.798l2.534 41.84.774-.09-.293-10.986c-.114-1.837.904-3.55 2.493-4.139a24.39 24.39 0 013.365-.979c1.442 3.78 3.21 7.003 5.23 9.827 2.022-2.824 3.79-6.048 5.232-9.827 1.14.245 2.265.571 3.365.98 1.589.587 2.607 2.301 2.493 4.138L24.9 78.548l.774.09 2.534-41.84-.774-.082L26.04 53.67c-.105 1.674-1.124 3.102-2.574 3.616-.88.319-1.785.588-2.697.808 1.621-5.738 2.55-12.619 2.55-21.059 0-16.871-3.715-29.27-9.215-36.975-5.5 7.705-9.215 20.104-9.215 36.975 0 8.44.929 15.321 2.55 21.06-.912-.221-1.817-.49-2.697-.809-1.45-.514-2.469-1.942-2.574-3.616L.774 36.716 0 36.798z" />
</svg>
      </a>
    </div>

    <nav class="c-header__navigation">
      <ul class="c-middle-nav">
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-210 menu-item-has-children">
      <a href="https://www.hypergiant.com/about/" class="c-middle-nav__link">Company</a>

              <ul class="c-middle-nav__sub-links">
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/about/" class="c-middle-nav__sub-link  menu-item menu-item-type-custom menu-item-object-custom menu-item-4231">About</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/rd/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-4232">R&#038;D</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/a-better-world/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-5217">A Better World</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/ethics/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-5216">Ethics</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/partners/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-5215">Partners</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/advisory/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-4233">Advisory</a>
            </li>
                  </ul>
          </li>
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-2034 menu-item-has-children">
      <a href="https://www.hypergiant.com/divisions/" class="c-middle-nav__link">Divisions</a>

              <ul class="c-middle-nav__sub-links">
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/divisions/space-age-solutions/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-214">DIV 00001<br>Space age solutions</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/divisions/sensory-sciences/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-2310">DIV 00002<br>Sensory Sciences</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/divisions/machine-learning-startups/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-212">DIV 00003<br>Hypergiant Ventures</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="https://www.hypergiant.com/divisions/galactic/" class="c-middle-nav__sub-link  menu-item menu-item-type-post_type menu-item-object-page menu-item-3020">DIV 00004<br>Galactic Systems</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="#" class="c-middle-nav__sub-link unclickable redacted menu-item menu-item-type-custom menu-item-object-custom menu-item-438">DIV 00005<br>[REDACTED]</a>
            </li>
                      <li class="c-middle-nav__sub-link-cont">
              <a href="#" class="c-middle-nav__sub-link unclickable redacted menu-item menu-item-type-custom menu-item-object-custom menu-item-3021">DIV 00006<br>[REDACTED]</a>
            </li>
                  </ul>
          </li>
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-209">
      <a href="https://www.hypergiant.com/case-studies-design-thinking-process/" class="c-middle-nav__link">Client Solutions</a>

          </li>
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-1185">
      <a href="https://www.hypergiant.com/press-page/" class="c-middle-nav__link">Press</a>

          </li>
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-1092">
      <a href="https://www.hypergiant.com/transcripts/" class="c-middle-nav__link">Transcripts</a>

          </li>
    
  
  
    <li class="c-middle-nav__link-cont  menu-item menu-item-type-post_type menu-item-object-page menu-item-986">
      <a href="https://www.hypergiant.com/contact/" class="c-middle-nav__link">Contact</a>

          </li>
  </ul>
    </nav>

    <div class="c-header__hamburger-container">
      <span class="c-header__hamburger-title">INDEX</span>
      <a href="#" class="c-header__hamburger" title="" data-menu-open></a>
    </div>
  </div>


</header>
  
    Sorry, we couldn't find what you're looking for.

      <footer class="c-footer">
  <div class="c-footer__container">
    <div class="c-footer__top">
      <div class="c-footer__logo-container">
                  <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 177 80">
  <path class="logo-fill"
    d="M66.54 15.153v21.142h-3.226v-6.473h-8.67v6.473h-3.227V15.123h3.227v11.856h8.67V15.153zM96.785 15.123l-6.4 10.48-.967 1.484.06 2.302v6.906h-3.472v-9.209l-1.118-1.817-6.25-10.146h3.563l4.318 6.966 1.178 1.969 1.177-1.939 4.288-6.996zM112.079 28.191h3.974c2.3-.12 4.213-2.304 4.213-5.088 0-2.575-1.733-4.73-3.914-5.029h-4.273v10.117zm3.257 2.814h-3.257v5.208h-3.137V15.26H116.352c3.764.18 6.782 3.622 6.782 7.843 0 3.233-1.733 6.046-4.243 7.243 0 0-1.165.659-3.555.659zM139.037 18.074v8.92h8.187v2.814h-8.187V33.4h9.561v2.813H135.96V15.26h12.64v2.814zM163.6 28.251h3.944c2.33-.15 4.243-2.364 4.243-5.088 0-2.635-1.733-4.79-3.914-5.06H163.6v10.148zm6.783 2.155l4.183 5.807h-4.004l-3.705-5.178H163.6v5.178h-3.137V15.26H167.873v.06c3.764.12 6.783 3.622 6.783 7.843 0 3.233-1.734 5.986-4.273 7.243zM71.657 57.125c0 6.076-4.273 10.925-10.577 10.925-5.947 0-10.787-4.849-10.787-10.925 0-6.017 4.84-10.985 10.787-10.985 4.571 0 7.021 1.915 8.963 3.831l-2.6 2.035c-1.314-1.227-3.286-2.604-6.363-2.604-4.094 0-7.38 3.442-7.38 7.723 0 4.31 3.286 7.782 7.38 7.782 3.227 0 6.035-1.945 6.931-5.208h-5.228v-2.934h8.874v.36zM85.938 67.706h3.257V46.753h-3.257zM114.086 61.6s-.538-1.168-.747-1.707c-.448-1.257-.896-2.274-1.106-2.873-1.015-2.544-1.553-4.25-1.553-4.25s-.657 1.736-1.674 4.25a75.929 75.929 0 01-1.105 2.873 66.439 66.439 0 01-.717 1.707s.419-.06 3.496-.06c3.048 0 3.406.06 3.406.06m1.046 2.723h-9.023c-.718 1.857-1.315 3.353-1.315 3.353h-3.347l9.173-21.432 9.233 21.432h-3.347s-.597-1.496-1.374-3.353M131.179 46.304l11.533 11.404 2.51 2.605-.03-3.203V46.783h3.436v21.192l-12.1-11.733-2.062-2.215.03 2.604v10.955h-3.317zM176.359 46.813v2.993h-6.275v17.87h-3.525v-17.87h-6.096v-2.993zM0 36.798l2.534 41.84.774-.09-.293-10.986c-.114-1.837.904-3.55 2.493-4.139a24.39 24.39 0 013.365-.979c1.442 3.78 3.21 7.003 5.23 9.827 2.022-2.824 3.79-6.048 5.232-9.827 1.14.245 2.265.571 3.365.98 1.589.587 2.607 2.301 2.493 4.138L24.9 78.548l.774.09 2.534-41.84-.774-.082L26.04 53.67c-.105 1.674-1.124 3.102-2.574 3.616-.88.319-1.785.588-2.697.808 1.621-5.738 2.55-12.619 2.55-21.059 0-16.871-3.715-29.27-9.215-36.975-5.5 7.705-9.215 20.104-9.215 36.975 0 8.44.929 15.321 2.55 21.06-.912-.221-1.817-.49-2.697-.809-1.45-.514-2.469-1.942-2.574-3.616L.774 36.716 0 36.798z" />
</svg>
              </div>

      <ul class="c-footer__top-divisions">

                  <li class="c-footer__top-division ">
            <h3 class="c-footer__title">Austin</h3>

            <div class="c-footer__top-division-part">
                <a href="mailto:info@hypergiant.com">info@hypergiant.com</a>
                <a href="tel:+1-737-808-4055"><span>737.808.4055</span></a>
            </div>

            <div class="c-footer__top-division-part">
              <span>
                101 W 6th St #400
              </span>

              <span>
                Austin, TX 78701
              </span>
            </div>
          </li>
                  <li class="c-footer__top-division ">
            <h3 class="c-footer__title">Dallas</h3>

            <div class="c-footer__top-division-part">
                <a href="mailto:info@hypergiant.com">info@hypergiant.com</a>
                <a href="tel:+1-737-808-4055"><span>737.808.4055</span></a>
            </div>

            <div class="c-footer__top-division-part">
              <span>
                5350 Alpha Road
              </span>

              <span>
                Dallas, TX 75240
              </span>
            </div>
          </li>
                  <li class="c-footer__top-division c-footer__top-division--redacted o-not-selectable">
            <h3 class="c-footer__title">Houston</h3>

            <div class="c-footer__top-division-part">
                <a href="mailto:info@hypergiant.com">info@hypergiant.com</a>
                <a href="tel:+1-737-808-4055"><span>737.808.4055</span></a>
            </div>

            <div class="c-footer__top-division-part">
              <span>
                2211 Norfolk Street <BR>  Sub Basement 410
              </span>

              <span>
                Houston, TX 77098
              </span>
            </div>
          </li>
        
      </ul>
    </div>

    <div class="c-footer__center">
      <div class="c-footer__bottom-part-1">
        <ul class="c-footer__social-links">


                      <li class="c-footer__social-link-item">
              <a href="http://twitter.com/hypergiant" class="c-social-link c-social-link--twitter"></a>
            </li>
                      <li class="c-footer__social-link-item">
              <a href="http://www.linkedin.com/company/hypergiant" class="c-social-link c-social-link--linkedin"></a>
            </li>
                      <li class="c-footer__social-link-item">
              <a href="http://www.instagram.com/hypergiant/" class="c-social-link c-social-link--instagram"></a>
            </li>
                      <li class="c-footer__social-link-item">
              <a href="http://youtube.com/c/HypergiantIndustries" class="c-social-link c-social-link--youtube"></a>
            </li>
                  </ul>
      </div>

      <div class="c-footer__bottom-part-2">
        <ul class="c-footer__list">
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-304" href="https://www.hypergiant.com/">Home</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-56" href="https://www.hypergiant.com/about/">Company</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-55" href="https://www.hypergiant.com/case-studies-design-thinking-process/">Client Solutions</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-1186" href="https://www.hypergiant.com/press-page/">Press</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-53" href="https://www.hypergiant.com/transcripts/">Transcripts</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-52" href="https://www.hypergiant.com/careers/">Careers</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-51" href="https://www.hypergiant.com/contact/">Contact</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-post_type menu-item-object-page menu-item-6326" href="https://www.hypergiant.com/signup/">Newsletters</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link   menu-item menu-item-type-custom menu-item-object-custom menu-item-7042" href="https://hypergiant.tv">Hypergiant.tv</a>
            </li>
                  </ul>

        <ul class="c-footer__list c-footer__list--spread">
                      <li class="c-footer__list-item">
              <a class="c-footer__link" href="https://www.hypergiant.com/privacy/">Privacy</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link" href="https://www.hypergiant.com/terms-of-use/">Terms of use</a>
            </li>
                      <li class="c-footer__list-item">
              <a class="c-footer__link" href="mailto:legal@hypergiant.com">Legal</a>
            </li>
                  </ul>

        <p class="c-footer__copy">
          © 2020 Hypergiant, LLC et al. All rights reserved
        </p>
      </div>
    </div>
    <div class="c-footer__bottom">
      <p class="c-footer__text">
        <b>RECENTLY DECLASSIFIED REPORTS & ANALYSIS - JULY 4, 1947</b> All data contained herein is exclusive property of Hypergiant Industries. No part of this site may be reproduced, distributed, or transmitted in any form or by any means, including photocopying, recording, or other electronic or mechanical methods. In the event of infringement, Hypergiant may seek immediate injunction and remuneration as necessary.
     
      </p>
    </div>
  </div>
</footer>
<!-- redirects -->
  <script>

   var url = window.location.href;
   console.log(url);
   var redirects = {
    "https://www.hypergiant.com/divisions/hypergiant-ventures/":"https://www.hypergiant.com/divisions/machine-learning-startups/",
    "https://hypergiant.com/case-studies/":"https://hypergiant.com/case-studies-design-thinking-process/",
    "https://hypergiant.com/client/case-study-05099/":"https://www.hypergiant.com/client/case-study-05009-ai-machine-learning-smarter-car/",
    "https://hypergiant.com/client/case-study-01099/":"https://www.hypergiant.com/client/case-study-01009-wearable-ai-solutions/",
    "https://hypergiant.com/client/case-study-02099/":"https://www.hypergiant.com/client/case-study-02099-oil-drilling-machine-intelligence-api-strategy/",
    "https://hypergiant.com/client/case-study-03099/":"https://www.hypergiant.com/client/case-study-03033-home-improvement-machine-intelligence-application/",
    "https://hypergiant.com/client/case-study-06099/":"https://www.hypergiant.com/client/case-study-06099-what-is-gaming-ai/",
    "https://hypergiant.com/client/case-study-04099/":"https://www.hypergiant.com/client/case-study-04099-machine-learning-k-nearest-neighbor/",
    "https://hypergiant.com/client/rod-lift-inventory-system/":"https://www.hypergiant.com/client/rod-lift-inventory-system-ai-consulting/",
    "https://hypergiant.com/client/tgi-fridays-a-i-mixologist/":"/client/tgi-fridays-a-i-mixologist-ai-technology/",
    "https://www.hypergiant.com/signup":"https://www.hypergiant.com/contact/#newsletter-signup",
    "https://www.hypergiant.com/signup/":"https://www.hypergiant.com/contact/#newsletter-signup",
    "https://www.hypergiant.com/seops":"https://www.hypergiant.com/divisions/galactic/",
    "https://www.hypergiant.com/seops/":"https://www.hypergiant.com/divisions/galactic/",
    "https://www.hypergiant.com/tv":"https://hypergiant.tv",
    "https://www.hypergiant.com/tv/":"https://hypergiant.tv",
   }
   if(url in redirects == true){
      console.log(redirects[url]);
      window.location.href = redirects[url];
   }
  </script>

<!-- analytics -->
<script>

  if(document.getElementById('contactSubmit')){
    document.getElementById('contactSubmit').onclick = function(){contactSubmitFunction()};
    function contactSubmitFunction(){
      ga('send', 'event', 'Contact', 'Click', 'Contact Form Submit Click');
    };
  }

  if(document.getElementById('contactPhone')){
    document.getElementById('contactPhone').onclick = function(){contactPhoneFunction()};
    function contactPhoneFunction(){
      ga('send', 'event', 'Contact', 'Click', 'Contact Phone Click Submit');
    };
  }


</script>

<!-- lead forensics -->
<script type="text/javascript" src="https://secure.leadforensics.com/js/145578.js" ></script>
<noscript><img src="https://secure.leadforensics.com/145578.png" style="display:none;" alt="" /></noscript>
<!-- Start of HubSpot Embed Code -->
<script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/4612442.js"></script>
<!-- End of HubSpot Embed Code -->
    <script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.hypergiant.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.hypergiant.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.6'></script>
<script type='text/javascript' async src='https://www.hypergiant.com/wp-includes/js/wp-embed.min.js'></script>

</body>
</html>
